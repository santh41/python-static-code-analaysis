import json
import csv
import subprocess

# Define output file paths
json_file_path = "lizard_output.json"
csv_file_path = "lizard_output.csv"

# Run Lizard and capture output
print("🔍 Running Lizard complexity analysis...")
lizard_command = ["lizard", "-l", "python"]

result = subprocess.run(lizard_command, text=True, capture_output=True)

# Debugging: Show raw Lizard output
print(result.stdout)
print(result.stderr)

# Check return code (Lizard might return a nonzero code even when it succeeds)
if "NLOC" not in result.stdout:
    print("❌ Lizard execution failed! No valid output found.")
    exit(1)

print("✅ Lizard executed successfully!")

# Convert Lizard output to JSON manually
try:
    lines = result.stdout.split("\n")  # Split by lines
    data = []

    for line in lines:
        parts = line.split()  # Split by spaces/tabs
        if len(parts) >= 6 and parts[1].isdigit():  # Checking if the line has function data
            complexity = int(parts[1])  # Convert CCN to integer

            # Assign severity levels
            if complexity <= 5:
                severity = "Low"
            elif 6 <= complexity <= 10:
                severity = "Medium"
            else:
                severity = "High"

            data.append({
                "filename": parts[-1],  # Last column contains the filename
                "function_name": parts[5].split("@")[0],  # Extract function name
                "start_line": parts[5].split("@")[1].split("-")[0],  # Extract start line
                "complexity": complexity,  # CCN (Cyclomatic Complexity)
                "parameters": parts[3],  # Number of parameters
                "length": parts[4],  # Function length
                "severity": severity  # Added severity level
            })

    # Save JSON manually
    with open(json_file_path, "w") as json_file:
        json.dump(data, json_file, indent=4)

    if not data:
        print("⚠️ No complexity issues found. CSV file will not be generated.")
        exit(0)

    # Define CSV headers (added "severity" and "message" columns)
    csv_headers = ["filename", "function_name", "start_line", "complexity", "severity", "parameters", "length", "message"]

    # Convert JSON to CSV
    print("📄 Converting JSON output to CSV...")
    with open(csv_file_path, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(csv_headers)  # Write header row

        for function in data:
            message = f"Function '{function['function_name']}' in {function['filename']} has a complexity of {function['complexity']} (Severity: {function['severity']})."
            writer.writerow([
                function["filename"],
                function["function_name"],
                function["start_line"],
                function["complexity"],
                function["severity"],  # Added severity
                function["parameters"],
                function["length"],
                message  # Added message column
            ])

    print(f"✅ CSV file '{csv_file_path}' generated successfully!")

except Exception as e:
    print(f"❌ Error processing Lizard output: {str(e)}")
    exit(1)
