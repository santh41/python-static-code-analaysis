import json
import csv
import subprocess

# Step 1: Run Radon command and save output in JSON format
radon_command = "radon cc . --json"
process = subprocess.run(radon_command, shell=True, capture_output=True, text=True)

# Ensure output is not empty
if not process.stdout.strip():
    print("❌ Error: Radon output is empty. Check if the directory contains valid Python files.")
    exit(1)

# Save JSON output to a file
with open("radon_output.json", "w") as json_file:
    json_file.write(process.stdout)

# Step 2: Read the JSON file and ensure valid JSON format
try:
    with open("radon_output.json", "r") as f:
        data = json.load(f)
except json.JSONDecodeError:
    print("❌ Error: Failed to parse JSON. Ensure Radon output is correct.")
    exit(1)

# Step 3: Define severity levels and messages based on complexity
def get_severity_and_message(complexity):
    """Assign severity and message based on complexity score"""
    if complexity <= 5:
        return "Low", "Good code quality, minimal complexity"
    elif 6 <= complexity <= 10:
        return "Medium", "Manageable complexity, could be refactored"
    elif 11 <= complexity <= 20:
        return "High", "Complex function, consider breaking it down"
    else:
        return "Critical", "Very complex function, likely hard to maintain"

# Step 4: Convert JSON to CSV
csv_filename = "radon_output.csv"

with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["File", "Function", "Line Number", "Complexity", "Rank", "Severity", "Message"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    for file, functions in data.items():
        if not isinstance(functions, list):
            print(f"❌ Warning: Skipping {file} due to unexpected structure: {functions}")
            continue

        for function in functions:
            if isinstance(function, str):
                try:
                    function = json.loads(function)  # Ensure function is parsed
                except json.JSONDecodeError:
                    print(f"❌ Error parsing function data: {function}")
                    continue

            if isinstance(function, dict) and "complexity" in function:
                severity, message = get_severity_and_message(function["complexity"])
                writer.writerow({
                    "File": file,
                    "Function": function.get("name", "Unknown"),
                    "Line Number": function.get("lineno", "N/A"),
                    "Complexity": function.get("complexity", "N/A"),
                    "Rank": function.get("rank", "N/A"),
                    "Severity": severity,
                    "Message": message
                })
            else:
                print(f"❌ Skipping function due to unexpected format: {function}")

print(f"✅ CSV report generated: {csv_filename}")
