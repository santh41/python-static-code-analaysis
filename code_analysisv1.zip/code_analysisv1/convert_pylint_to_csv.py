import json
import csv
import subprocess

# Define paths for JSON and CSV output
json_file_path = "pylint.json"
csv_file_path = "pylint.csv"

# Define severity levels for Pylint issue types
SEVERITY_MAPPING = {
    "convention": "Low",
    "refactor": "Low",
    "warning": "Medium",
    "error": "High",
    "fatal": "High"
}

# Step 1: Run Pylint and save output as JSON
print("🔍 Running Pylint analysis...")
pylint_command = [
    "pylint", "--recursive=y", "/var/tmp/python-mini-projects.git",
    "--output-format=json"
]
try:
    pylint_output = subprocess.run(pylint_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    # Print stderr (if any) for debugging
    if pylint_output.stderr:
        print("⚠️ Pylint STDERR:", pylint_output.stderr)
    
    # Write JSON output even if Pylint returns errors
    with open(json_file_path, "w") as json_file:
        json_file.write(pylint_output.stdout)
    
    print(f"✅ Pylint JSON output saved to '{json_file_path}'")

except Exception as e:
    print("❌ Pylint execution failed:", str(e))
    exit(1)

# Step 2: Convert JSON to CSV
print("📄 Converting JSON output to CSV...")
try:
    with open(json_file_path, "r") as json_file:
        data = json.load(json_file)

    # Define CSV headers
    csv_headers = ["type", "severity", "module", "line", "column", "path", "symbol", "message"]

    # Write to CSV file
    with open(csv_file_path, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(csv_headers)  # Write header row

        for entry in data:
            severity = SEVERITY_MAPPING.get(entry.get("type", ""), "Unknown")  # Map severity
            writer.writerow([
                entry.get("type", ""),
                severity,
                entry.get("module", ""),
                entry.get("line", ""),
                entry.get("column", ""),
                entry.get("path", ""),
                entry.get("symbol", ""),
                entry.get("message", ""),
            ])

    print(f"✅ CSV file '{csv_file_path}' generated successfully!")

except Exception as e:
    print("❌ Error processing JSON to CSV:", str(e))
    exit(1)
