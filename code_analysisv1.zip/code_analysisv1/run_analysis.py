import os
import subprocess
import sys
import shutil
import pandas as pd  # For merging CSVs

def clone_repo(git_url, dest_folder="cloned_repo"):
    """Clones the given GitHub repo to a local directory."""
    if os.path.exists(dest_folder):
        shutil.rmtree(dest_folder)  # Remove existing repo if already cloned
    print(f"🔄 Cloning repository: {git_url}...")
    subprocess.run(["git", "clone", git_url, dest_folder], check=True)
    return os.path.abspath(dest_folder)

def copy_scripts(repo_path, scripts):
    """Copies analysis scripts to the cloned repository directory."""
    for script in scripts:
        shutil.copy(script, repo_path)  # Move scripts inside repo folder

def create_output_folder(repo_path):
    """Creates an 'output' folder inside the repo to store CSV files."""
    output_dir = os.path.join(repo_path, "output")
    os.makedirs(output_dir, exist_ok=True)
    return output_dir

def run_scripts(repo_path, scripts, output_dir):
    """Runs each analysis script inside the cloned repo and ensures CSV files are in the output directory."""
    os.chdir(repo_path)  # Change directory to repo
    for script in scripts:
        print(f"🚀 Running {script} ...")
        try:
            subprocess.run(["python3", script, output_dir], check=True)
        except subprocess.CalledProcessError as e:
            print(f"❌ Error running {script}: {e}")
            sys.exit(1)  # Exit if any script fails

def merge_csv_files(output_dir, final_csv):
    """Merges all CSV files in the output directory into a standardized report."""
    csv_files = [os.path.join(output_dir, f) for f in os.listdir(output_dir) if f.endswith(".csv")]
    if not csv_files:
        print("⚠️ No CSV files found to merge!")
        return

    dataframes = []
    for file_path in csv_files:
        df = pd.read_csv(file_path)
        df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]  # Standardize column names
        df.fillna("N/A", inplace=True)  # Fill missing values with "N/A"
        df["Source"] = os.path.basename(file_path).replace(".csv", "")  # Add source column
        dataframes.append(df)

    merged_df = pd.concat(dataframes, ignore_index=True)
    merged_df.to_csv(final_csv, index=False)
    print(f"✅ Merged CSV saved at: {final_csv}")

def move_csv_files(repo_path, output_dir):
    """Moves CSV files from cloned_repo to output directory if needed."""
    repo_csv_files = [f for f in os.listdir(repo_path) if f.endswith(".csv")]
    for file in repo_csv_files:
        shutil.move(os.path.join(repo_path, file), os.path.join(output_dir, file))

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 run_analysis.py <GitHub_Repo_URL>")
        sys.exit(1)

    git_url = sys.argv[1]
    repo_path = clone_repo(git_url)

    scripts = [
        "convert_radon_to_csv.py",
        "convert_bandit_to_csv.py",
        "convert_lizard_to_csv.py",
        "convert_pylint_to_csv.py"
    ]

    copy_scripts(repo_path, scripts)  # Copy scripts to cloned repo directory
    output_dir = create_output_folder(repo_path)  # Ensure output folder exists
    run_scripts(repo_path, scripts, output_dir)  # Execute scripts in the repo directory

    move_csv_files(repo_path, output_dir)  # Move CSVs to output directory
    final_csv = os.path.join(output_dir, "final_report.csv")
    merge_csv_files(output_dir, final_csv)  # Merge all CSV files

    print("✅ All scripts executed and report generated successfully!")

if __name__ == "__main__":
    main()
