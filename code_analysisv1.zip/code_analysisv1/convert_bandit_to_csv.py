import json
import csv
import subprocess

# Define output file paths
json_file_path = "bandit_output.json"
csv_file_path = "bandit_output.csv"

# Run Bandit and save output as JSON
print("🔍 Running Bandit security scan...")
bandit_command = ["bandit", "-r", ".", "-iii", "-ll", "-f", "json", "-o", json_file_path]

result = subprocess.run(bandit_command, text=True, capture_output=True)

# Debugging: Show Bandit output
print(result.stdout)
print(result.stderr)

if result.returncode not in [0, 1]:  # Bandit returns 0 (no issues) or 1 (issues found)
    print("❌ Bandit execution failed!")
    exit(1)

print("✅ Bandit executed successfully!")

# Convert JSON to CSV
try:
    with open(json_file_path, "r") as json_file:
        data = json.load(json_file)

    # Ensure "results" key exists and has data
    if not data or "results" not in data or not data["results"]:
        print("⚠️ No security issues found. CSV file will not be generated.")
        exit(0)

    # Define CSV headers (added "message" column)
    csv_headers = ["filename", "line", "test_id", "severity", "confidence", "issue_text", "message"]

    # Convert JSON to CSV
    print("📄 Converting JSON output to CSV...")
    with open(csv_file_path, "w", newline="") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(csv_headers)  # Write header row

        for result in data["results"]:
            # Create a user-friendly message
            message = f"Security issue in {result.get('filename', '')} at line {result.get('line_number', '')}: {result.get('issue_text', '')}"
            
            writer.writerow([
                result.get("filename", ""),
                result.get("line_number", ""),
                result.get("test_id", ""),
                result.get("issue_severity", ""),
                result.get("issue_confidence", ""),
                result.get("issue_text", ""),
                message  # Added message column
            ])

    print(f"✅ CSV file '{csv_file_path}' generated successfully!")

except json.JSONDecodeError:
    print("❌ Error: JSON file is empty or corrupted.")
    exit(1)
except Exception as e:
    print(f"❌ Error processing JSON to CSV: {str(e)}")
    exit(1)
